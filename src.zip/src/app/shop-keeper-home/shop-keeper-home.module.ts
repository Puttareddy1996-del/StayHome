import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ShopKeeperHomePageRoutingModule } from './shop-keeper-home-routing.module';

import { ShopKeeperHomePage } from './shop-keeper-home.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ShopKeeperHomePageRoutingModule
  ],
  declarations: [ShopKeeperHomePage]
})
export class ShopKeeperHomePageModule {}
