import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShopKeeperHomePage } from './shop-keeper-home.page';

const routes: Routes = [
  {
    path: '',
    component: ShopKeeperHomePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ShopKeeperHomePageRoutingModule {}
