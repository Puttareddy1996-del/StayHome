import { Component, OnInit } from '@angular/core';
import { NavController, IonSlides } from '@ionic/angular';

import { AuthenticateService } from '../services/authentication.service';
import * as firebase from 'firebase/app';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from "@angular/fire/firestore";

import { Observable, BehaviorSubject} from 'rxjs';
import { first } from 'rxjs/operators';

import { CartService } from '../services/cart.service';

import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-shop-keeper-home',
  templateUrl: './shop-keeper-home.page.html',
  styleUrls: ['./shop-keeper-home.page.scss'],
})
export class ShopKeeperHomePage implements OnInit {
  private albumDoc: AngularFirestoreDocument<any>;
  album: Observable<any>;
  userEmail: string;
  selectedSlide:any;
  segment=0;
  items: Observable<any[]>;
  covid: Observable<any[]>;
  taken: boolean=true;
  ordList:Observable<any[]>; 
  booked:Observable<any[]>;

  itemsRef: AngularFirestoreCollection;  
  segments: string = "Vegitables";
  
  
  

  
  sliderOptions={
    initialSlide:0,
    slidePerView:1,
    speed:400
  }
  uid: string;
  name: any;
  imageUrl: any;
  email: any;
  phone: any;
  address: any;
  state: any;
  pincode: any;
  city: any;
  bd: any;
  imgSrc: any;
  isTaken:any;
  constructor(
    private navCtrl: NavController,
    private authService: AuthenticateService,
    public db: AngularFirestore,
    public cartService: CartService,
  
    public afAuth: AngularFireAuth
    
  ) {  
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.uid=res.uid;
    
  this.albumDoc = db.doc<any>(`users/${this.uid}`);
  this.album = this.albumDoc.valueChanges();
  this.album.subscribe(value => {
    this.imageUrl = value.imageUrl;
    this.name = value.Name;
    this.email=value.Email;
    this.phone=value.PhoneNo;
    this.address=value.Address;
    this.state=value.State;
    this.pincode=value.Pincode;
    this.city=value.City;
    this.bd=value.BDate;
    this.imgSrc=this.imageUrl;
    
  this.itemsRef = db.collection('newsDetails')
  this.items = this.itemsRef.valueChanges(); 

  this.itemsRef = db.collection('Covid-Updates')
  this.covid = this.itemsRef.valueChanges(); 

   screen.orientation.lock('portrait');
  
   this.itemsRef=db.collection('ReadyOrders').doc(this.pincode).collection('orders')
   this.ordList=this.itemsRef.valueChanges();
  })
}
    })
}

 
async ngOnInit() {
    
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.navCtrl.navigateBack('/thanks');
      }
    }, err => {
      console.log('err', err);
    })

   

   
   

  }

  logout() {
    this.authService.logoutUser()
      .then(res => {
        console.log(res);
        this.navCtrl.navigateBack('/thanks ');
      })
      .catch(error => {
        console.log(error);
      })
  }
  async segmentChanged(ev){
    await this.selectedSlide.slideTo(this.segment);
  }

  slideChanged(slides:IonSlides){
    this.selectedSlide=slides;
    slides.getActiveIndex().then(selectedIndex => {this.segment=selectedIndex;})
  }
  async segmentsChanged() {
    this.segments}

    acceptTo(location){
      const pincode=location.Pincode;
      const custUID=location.uid;
      const Taken=location.Taken;
      if(Taken==false){
        
        this.db.collection('ReadyOrders').doc(pincode).collection('orders').doc(custUID).update({Taken:this.taken,Processed:'Done'});
        
        this.itemsRef=this.db.collection('users').doc(custUID).collection('orders')
        this.booked=this.itemsRef.valueChanges();
     
      }
      
    } 
   
   }
