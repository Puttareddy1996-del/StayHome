import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ShopKeeperHomePage } from './shop-keeper-home.page';

describe('ShopKeeperHomePage', () => {
  let component: ShopKeeperHomePage;
  let fixture: ComponentFixture<ShopKeeperHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShopKeeperHomePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ShopKeeperHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
