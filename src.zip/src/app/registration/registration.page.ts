import { Component, OnInit, NgZone } from '@angular/core';

import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AuthenticateService } from '../services/authentication.service';
import { NavController } from '@ionic/angular';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument} from "@angular/fire/firestore";
import * as firebase from 'firebase/app';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFireStorage } from '@angular/fire/storage';
import { Router } from '@angular/router';
import { UserService } from "../services/user.service";
import { LoadingController } from '@ionic/angular';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.page.html',
  styleUrls: ['./registration.page.scss'],
})
export class RegistrationPage implements OnInit {

  validations_form: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';
  imgSrc: any;
  selectedFile: any;
  imageUrl: String='';
  loading: HTMLIonLoadingElement;
  validation_messages = {
    'email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Enter a valid email.' }
    ],
    'password': [
      { type: 'required', message: 'Password is required.' },
      { type: 'minlength', message: 'Must be at least 5 characters' }
    ]
  };
  itemsRef: AngularFirestoreCollection;
  userData: firebase.User;
 
  constructor(
    private navCtrl: NavController,
    private authService: AuthenticateService,
    private formBuilder: FormBuilder,
    private db: AngularFirestore,
    private afAuth: AngularFireAuth,
    private loadingController: LoadingController,
    private storage: AngularFireStorage,
    public ngZone: NgZone,
    public router: Router

  ) {
    this.afAuth.authState.subscribe(user => {
      if (user) {
        this.userData = user;
        localStorage.setItem('user', JSON.stringify(this.userData));
        JSON.parse(localStorage.getItem('user'));
      } else {
        localStorage.setItem('user', null);
        JSON.parse(localStorage.getItem('user'));
      }
    })
    this.itemsRef = db.collection('users')

    screen.orientation.lock('portrait');
   }

  ngOnInit() {
    this.validations_form = this.formBuilder.group({
      Name: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      pincode: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      address: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      phoneNo: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      state: new FormControl('', Validators.compose([
        Validators.required,
       
      ])),
      city: new FormControl('', Validators.compose([
        Validators.required,
       
      ])),
      
      date: new FormControl('', Validators.compose([
        Validators.required,
       
      ])),
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      password: new FormControl('', Validators.compose([
        Validators.minLength(5),
        Validators.required
      ])),
      imageUrl: new FormControl('', Validators.compose([
       
        Validators.required
      ])),
    });

    this.imgSrc = '/assets/img/1.png';
  }
  chooseFile(event: any) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e: any) => this.imgSrc = e.target.result;
      reader.readAsDataURL(event.target.files[0]);
      this.selectedFile = event.target.files[0];
      this.selectedFile = event.target.files
    }
    else {
      this.imgSrc = '/assets/img/1.png';
      
    }
  }
  tryRegister(value) {
    this.afAuth.createUserWithEmailAndPassword(value.email, value.password)
        .then(async result => {
          let uid= this.getEmail(result.user);
          this.imageUrl = await this.uploadFile(uid, this.selectedFile)
         
          this.db.doc('users/'+uid).update({
            
            imageUrl: this.imageUrl || null
          })
          
           
         this.SetUserData(result.user, value);
         await this.presentLoading();
         this.navCtrl.navigateForward('/choose-one');
         this.loading.dismiss();
       }).catch((error) => {
         window.alert(error)
       })

  }
  async presentLoading() {
    this.loading = await this.loadingController.create({
      message: 'Please wait...'
    });
    return this.loading.present();
  }
  SetUserData(user,value) {
    const userRef: AngularFirestoreDocument<any> = this.db.doc(`users/${user.uid}`);
    const userData: UserService = {
      uid: user.uid,
      Email: user.email,
      Name: value.Name,
      PhoneNo: value.phoneNo,
      Address: value.address,
      State: value.state,
      City: value.city,
      Pincode: value.pincode,
      BDate: value.date,
      imageUrl:this.imageUrl,
      emailVerified: user.emailVerified,
    }
    return userRef.set(userData, {
      merge: true
    })
  }

  getEmail(user){
    return user.uid;
  }
  async uploadFile(id, file): Promise<any> {
    if(file && file.length) {
      try {
       
        const task = await this.storage.ref('users').child(id).put(file[0])
        
        return this.storage.ref(`users/${id}`).getDownloadURL().toPromise();
      } catch (error) {
        console.log(error);
      }
    }
  }
  
  goLoginPage() {
    this.navCtrl.navigateBack('');
  }
 

}
