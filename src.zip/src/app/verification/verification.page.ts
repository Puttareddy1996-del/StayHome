import { Component, OnInit } from '@angular/core';
import { AuthenticateService } from '../services/authentication.service';
import { Router } from "@angular/router";
import { AngularFireAuth } from '@angular/fire/auth';
import * as firebase from 'firebase/app';
@Component({
  selector: 'app-verification',
  templateUrl: './verification.page.html',
  styleUrls: ['./verification.page.scss'],
})
export class VerificationPage implements OnInit {
  verificationId: any;
  code = '';
  phone: number;
  constructor(public authService: AuthenticateService,
             private afAuth: AngularFireAuth,
              private router: Router) {
                
    if(this.isEmailVerified) {
      this.router.navigate(['choose-one']);          
    } else {
      window.alert('Email is not verified')
      
    }
   }

  ngOnInit() {
  }
  get isEmailVerified(): boolean {
    const user = JSON.parse(localStorage.getItem('user'));
    return (user.emailVerified !== false) ? true : false;
  }

  send() {
    const tell = '+91' + this.phone;
    (<any> window).FirebasePlugin.verifyPhoneNumber(tell, 60, (credential) => {
      console.log(credential);
      this.verificationId = credential.verificationId;
    }, (error) => {
      console.error(error);
      alert(error);
     });
  }

  verify() {
    const signInCredential = firebase.auth.PhoneAuthProvider.credential(this.verificationId, this.code);
    firebase.auth().signInWithCredential(signInCredential).then((info) => {
      console.log(info);
      // this.navCtrl.navigateRoot('/home'); 
    }, (error) => {
      console.log(error);
    });
    }
  
}
