import { Component, OnInit } from '@angular/core';
import { NavController,MenuController, LoadingController } from '@ionic/angular';
import { AuthenticateService } from '../services/authentication.service';
   
@Component({
  selector: 'app-choose-one',
  templateUrl: './choose-one.page.html',
  styleUrls: ['./choose-one.page.scss'],
})
export class ChooseOnePage implements OnInit {

  userEmail: string;
  activeMenu: string;
  loading: any;

  constructor(
    private navCtrl: NavController,
    private authService: AuthenticateService,
    public menu: MenuController,
    public loadingCtrl: LoadingController
  ) {  this.menu1Active();
    screen.orientation.lock('portrait');}

  ngOnInit() {

    

    
   
  }
  
 
  
 
  menu1Active() {
    this.activeMenu = 'menu1';
    this.menu.enable(true);
    
  }
  
  



}
