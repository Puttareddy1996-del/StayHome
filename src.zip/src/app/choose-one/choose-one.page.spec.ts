import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ChooseOnePage } from './choose-one.page';

describe('ChooseOnePage', () => {
  let component: ChooseOnePage;
  let fixture: ComponentFixture<ChooseOnePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChooseOnePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ChooseOnePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
