import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChooseOnePageRoutingModule } from './choose-one-routing.module';

import { ChooseOnePage } from './choose-one.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChooseOnePageRoutingModule
  ],
  declarations: [ChooseOnePage]
})
export class ChooseOnePageModule {}
