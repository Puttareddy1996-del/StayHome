import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
 
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
 
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
 
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { environment } from '../environments/environment';
import { AngularFirestore, AngularFirestoreModule } from '@angular/fire/firestore';
import { CustomerHomePageModule } from './customer-home/customer-home.module';
import { RegistrationPageModule } from './registration/registration.module';
import { AngularFireStorageModule } from '@angular/fire/storage';
import {VerificationPageModule} from './verification/verification.module';
import { ForgetPasswordPageModule } from './forget-password/forget-password.module';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { ProfilePageModule } from './profile/profile.module';
@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    AngularFireAuthModule,
    RegistrationPageModule,
    ProfilePageModule,
    CustomerHomePageModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    VerificationPageModule,
    ForgetPasswordPageModule,
    AngularFireModule.initializeApp(environment.firebase)
  ],
  providers: [
    StatusBar,
    SplashScreen,
    AngularFirestore,
    ScreenOrientation,
       { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
       

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }