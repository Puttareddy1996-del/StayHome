import { Component,OnInit } from '@angular/core';
import { MenuController, NavController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { Platform } from '@ionic/angular';


import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFireStorage } from '@angular/fire/storage';
import { AuthenticateService } from '../app/services/authentication.service';
import { AngularFirestoreCollection, AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { map } from 'rxjs/internal/operators/map';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import * as firebase from 'firebase/app';
require('firebase/auth')
require('firebase/firestore')
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  userEmail: string;
  name: any;
  dp:any;
  itemsRef: AngularFirestoreCollection;
  userData:any;
  private albumDoc: AngularFirestoreDocument<any>;
  album: Observable<any>;
  userUID: string;
  uid: string='';
  userDatas: any;
  list: any;
  promotions: any;
  imgSrc: any;
  loading: HTMLIonLoadingElement;
  selectedFile: any;
  selectedImage: any = null;
  imageUrl: String='';
  linkRef: AngularFirestoreDocument<any>;
  link: Observable<any>;
  path: string;
  userDocRef: any;
  news: Observable<any>;
  email: any;
  phone: any;
   constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    public menu: MenuController,
    private afAuth: AngularFireAuth,
    public authService:AuthenticateService,
    public db: AngularFirestore,
    private storage: AngularFireStorage,
    private navCtrl: NavController,
    private router: Router,
    
    private loadingController: LoadingController
  ) {
    this.initializeApp();
    screen.orientation.lock('portrait');
    this.afAuth.authState.subscribe(user => {
      if (user) {
        this.userData = user;
        localStorage.setItem('user', JSON.stringify(this.userData));
        JSON.parse(localStorage.getItem('user'));
      } else {
        localStorage.setItem('user', null);
        JSON.parse(localStorage.getItem('user'));
      }
    })
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.uid=res.uid;
        this.userEmail = res.email;
        
        this.getUserData(this.uid);
      } 
    }, err => {
      console.log('err', err);
    })
    screen.orientation.lock('portrait');

   
   
  }
  ngOnInit() {
    
    
  }
  getUserData(email){
    
    this.albumDoc = this.db.doc<any>(`users/${email}`);
    this.album = this.albumDoc.valueChanges();
    this.album.subscribe(value => {
      this.imageUrl = value.imageUrl;
      this.name = value.Name;
      this.email=value.Email;
      this.phone=value.PhoneNo;
      
      this.imgSrc=this.imageUrl;
      
    });

  }
    
  async presentLoading() {
    this.loading = await this.loadingController.create({
      message: 'Please wait...'
    });
    return this.loading.present();
  }

 
  logout() {
    this.logoutUser()
      .then(res => {
        console.log(res);
        
      })
      .catch(error => {
        console.log(error);
      })
  }
  logoutUser() {
    return new Promise((resolve, reject) => {
      if (this.afAuth.currentUser) {
        this.afAuth.signOut()
          .then(() => {
            console.log("LOG Out");
            this.navCtrl.navigateBack('/thanks');
            resolve();
          }).catch((_error) => {
            reject();
          });
      }
    })
  }
  chooseFile(event: any) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e: any) => this.imgSrc = e.target.result;
      reader.readAsDataURL(event.target.files[0]);
      this.selectedFile = event.target.files[0];
      this.selectedFile = event.target.files
    }
    else {
      this.imgSrc = '/assets/img/1.png';
      
    }
  }
 
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  enableAuthenticatedMenu() {
    this.menu.enable(true, 'authenticated');
    this.menu.enable(false, 'unauthenticated');
  }
}
