import { Component, OnInit } from '@angular/core';
import { NavController, IonSlides } from '@ionic/angular';

import { AuthenticateService } from '../services/authentication.service';
import * as firebase from 'firebase/app';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from "@angular/fire/firestore";

import { Observable, BehaviorSubject} from 'rxjs';
import { first } from 'rxjs/operators';

import { CartService } from '../services/cart.service';

import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.page.html',
  styleUrls: ['./customer-home.page.scss'],
})

export class CustomerHomePage implements OnInit {
  userEmail: string;
  selectedSlide:any;
  segment=0;
  items: Observable<any[]>;
  covid: Observable<any[]>;
  vegs: Observable<any[]>;
  gs : Observable<any[]>;
  ordList:Observable<any[]>; 
  isTook:Observable<any[]>; 
  itemsRef: AngularFirestoreCollection;  
  segments: string = "Vegitables";
  public vegList: any[];
  public gsList: any[];
  private albumDoc: AngularFirestoreDocument<any>;
    album: Observable<any>;
  buttonColor:  'primary'
  isTaken:boolean;
  public cart:any[];
  cartItemCount: BehaviorSubject<number>;
  
  sliderOptions={
    initialSlide:0,
    slidePerView:1,
    speed:400
  }
  value: string;
  userId: string;
  uid:string;


  private orderRef: AngularFirestoreDocument<any>;
  sendOrd: Observable<any>;
  phone: any;
  address: any;
  state: any;
  pincode: string;
  city: any;
  name: any;
  id: any;
  imageUrl: any;
  takes: any;
  isTooked: any;
  Done: string;
  email: any;
  imgSrc: any;
  bd: any;
  process: any="not";
  constructor(
    private navCtrl: NavController,
    private authService: AuthenticateService,
    public db: AngularFirestore,
    public cartService: CartService,
  
    public afAuth: AngularFireAuth
    
  ) { this.itemsRef = db.collection('newsDetails')
  this.items = this.itemsRef.valueChanges(); 

  this.itemsRef = db.collection('Covid-Updates')
  this.covid = this.itemsRef.valueChanges(); 

  this.itemsRef = db.collection('vegitableItems')
  this.vegs = this.itemsRef.valueChanges();

  this.itemsRef = db.collection('generalStoreItems')
  this.gs = this.itemsRef.valueChanges();

  screen.orientation.lock('portrait');

  
  this.authService.userDetails().subscribe(res => {
    console.log('res', res);
    if (res !== null) {
      this.uid=res.uid;
  
const docRef = db.doc<any>(`ReadyOrders/${this.pincode}/orders/${res.uid}`);
this.album = docRef.valueChanges();
this.album.subscribe(value => {
  console.log(value)
  this.imageUrl = value.imageUrl;
  this.name = value.Name;
  this.email=value.Email;
  this.phone=value.PhoneNo;
  this.address=value.Address;
  this.state=value.State;
  this.pincode=value.Pincode;
  this.city=value.City;
  this.bd=value.BDate;
  this.imgSrc=this.imageUrl;
  
})

    }
  })

}

 
async ngOnInit() {
    
   

    this.vegList = await this.initializeVegItems();
    this.gsList = await this.initializeGsItems();

    let currentUser = firebase.auth().currentUser;
    this.uid=currentUser.uid;
    this.itemsRef =this.db.collection('users').doc(this.uid).collection('orders')
    this.ordList =this.itemsRef.valueChanges();

    this.cart = this.cartService.getCart();
    this.cartItemCount = this.cartService.getCartItemCount();

   

  }

  logout() {
    this.authService.logoutUser()
      .then(res => {
        console.log(res);
        this.navCtrl.navigateBack('/thanks ');
      })
      .catch(error => {
        console.log(error);
      })
  }
  async segmentChanged(ev){
    await this.selectedSlide.slideTo(this.segment);
  }

  slideChanged(slides:IonSlides){
    this.selectedSlide=slides;
    slides.getActiveIndex().then(selectedIndex => {this.segment=selectedIndex;})
  }
  async segmentsChanged() {
    this.segments}

    
    async initializeVegItems(): Promise<any> {
      const vegList = await this.db.collection('vegitableItems')
        .valueChanges().pipe(first()).toPromise();
      return vegList;
    }
    async onSearchVeg(event){
      this.vegList = await this.initializeVegItems();
      const searchTerm = event.srcElement.value;
    
      if (!searchTerm) {
        return;
      }
    
      this.vegList = this.vegList.filter(currentVeg => {
        if (currentVeg.vegName && searchTerm) {
          return (currentVeg.vegName.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1 );
        }
      });
      

    }

    async initializeGsItems(): Promise<any> {
      const gsList = await this.db.collection('generalStoreItems')
        .valueChanges().pipe(first()).toPromise();
      return gsList;
    }
    async onSearchGs(event){
      this.gsList = await this.initializeGsItems();
      const searchTerm = event.srcElement.value;
    
      if (!searchTerm) {
        return;
      }
    
      this.gsList = this.gsList.filter(currentGs => {
        if (currentGs.Name && searchTerm) {
          return (currentGs.Name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1 );
        }
      });
      

    }
    

    addToCart(p){
      this.cartService.addProduct(p);


      
    }
    
    
    
    decreaseCartItem(product){
      if(product.price<=0){
        let currentUser = firebase.auth().currentUser;
           this.db.collection('users').doc(currentUser.uid).collection('orders').doc(product.id).delete();
      
      }else{
        this.cartService.decreaseProduct(product);
      }
     
    }
  
    increaseCartItem(product){
      if(product.price<=0){
        let currentUser = firebase.auth().currentUser;
           this.db.collection('users').doc(currentUser.uid).collection('orders').doc(product.id).delete();
      
      }else{
      this.cartService.addProduct(product);
      }
    }
  
    removeCartItem(product){
      
      this.cartService.removeProduct(product);
    }
    isCollapsed:boolean=true;

   async confirmToAdd(p){

      
    }
    taken:String='';
    sendToValantire(){
      this.authService.userDetails().subscribe(res => {
        console.log('res', res);
        if (res !== null) {
          this.uid=res.uid;
          this.userEmail = res.email;
          this.orderRef = this.db.doc<any>(`users/${this.uid}`);
         this.sendOrd = this.orderRef.valueChanges();
        this.sendOrd.subscribe(value => {
      
      this.name=value.Name;
      this.phone=value.PhoneNo;
      this.address=value.Address;
      this.state=value.State;
      this.pincode=value.Pincode;
      this.city=value.City;
      this.imageUrl=value.imageUrl;
     
      this.db.collection('ReadyOrders').doc(this.pincode).collection('orders').doc(`${this.uid}`).set({Name:this.name,imageUrl:this.imageUrl,Address:this.address,PhoneNo:this.phone,Pincode:this.pincode,uid:this.uid,City:this.city,State:this.state,Taken:this.taken,Processed:this.process,});
          
        } ) }
      }, err => {
        console.log('err', err);
      })
    
    }
    
    isTakenOrNot(takes){
      if(takes==true){
        this.Done='Done';
      }
     
    }
   

}
