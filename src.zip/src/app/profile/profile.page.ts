import { Component, OnInit } from '@angular/core';
import { NavController, LoadingController } from '@ionic/angular';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from "@angular/fire/firestore";
import { Observable } from 'rxjs';
import { UserService } from "../services/user.service";
import * as firebase from 'firebase/app';
import { AuthenticateService } from '../services/authentication.service';
import { FormGroup, FormBuilder, FormControl,Validators } from '@angular/forms';
import { AngularFireStorage } from '@angular/fire/storage';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  userData: any[];
  itemsRef: AngularFirestoreCollection;  
  userEmail: string;
  uid: string;
  private albumDoc: AngularFirestoreDocument<any>;
  album: Observable<any>;
  imageUrl: any;
  name: any;
  email: any;
  phone: any;
  address: any;
  state: any;
  pincode: any;
  city: any;
  loading: HTMLIonLoadingElement;
  bd: any;
  validations_form: FormGroup;
  isDisabled:boolean=true;
  selectedFiles: any;
  imgSrc: any;
  imageUrls: any;
  password: any;
  constructor( private readonly afs:AngularFirestore,
               private authService: AuthenticateService,
               private formBuilder: FormBuilder,
               private storage: AngularFireStorage,
               private loadingController: LoadingController,
               private navCtrl: NavController,) {
                this.authService.userDetails().subscribe(res => {
                  console.log('res', res);
                  if (res !== null) {
                    this.uid=res.uid;
                    this.userEmail = res.email;
                    
                    this.getUserData(this.uid);
                  } 
                }, err => {
                  console.log('err', err);
                })
                
   }

  ngOnInit() {
    this.validations_form = this.formBuilder.group({
      name: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      pincode: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      address: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      phone: new FormControl('', Validators.compose([
        Validators.required,
        
      ])),
      state: new FormControl('', Validators.compose([
        Validators.required,
       
      ])),
      city: new FormControl('', Validators.compose([
        Validators.required,
       
      ])),
      
      bd: new FormControl('', Validators.compose([
        Validators.required,
       
      ])),
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      
      
    });
   
  }
  getUserData(uid){
    
    this.albumDoc = this.afs.doc<any>(`users/${uid}`);
    this.album = this.albumDoc.valueChanges();
    this.album.subscribe(value => {
      console.log(value)
      this.imageUrl = value.imageUrl;
      this.name = value.Name;
      this.email=value.Email;
      this.phone=value.PhoneNo;
      this.address=value.Address;
      this.state=value.State;
      this.pincode=value.Pincode;
      this.city=value.City;
      this.bd=value.BDate;
      this.imgSrc=this.imageUrl;
      
    });

  }
  enable(){
    this.isDisabled=false;
   
  }
async tryUpdate(value){
  let record = {};
  record['Name'] = value.name;
  record['Email'] = value.email;
  record['imageUrl']= await this.uploadFile(this.uid, this.selectedFiles);
  record['PhoneNo'] = value.phone;
  record['Address'] = value.address;
  record['State'] = value.state;
  record['Pincode'] = value.pincode;
  record['City'] = value.city;
  record['BDate'] = value.bd;
  record['emailVerified']=true;
  this.afs.doc(`users/${this.uid}`).update(record)
  
  
  
    this.updateUserData(record);
  console.log('successfully added')
}
updateUserData(value) {
 
  const userData: UserService = {
    uid:this.uid,
    Email: value.Email,
    Name: value.Name,
    PhoneNo: value.PhoneNo,
    Address: value.Address,
    State: value.State,
    City: value.City,
    Pincode: value.Pincode,
    BDate: value.BDate,
    imageUrl:value.imageUrl,
    emailVerified: true,
  }
  
}
async uploadFile(id, file): Promise<any> {
  if(file && file.length) {
    try {
      await this.presentLoading();
      const task = await this.storage.ref('users').child(id).put(file[0])
      this.loading.dismiss();
      return this.storage.ref(`users/${id}`).getDownloadURL().toPromise();
    } catch (error) {
      console.log(error);
    }
  }
}
async presentLoading() {
  this.loading = await this.loadingController.create({
    message: 'Please wait...'
  });
  return this.loading.present();
}
chooseFile(event: any) {
  if (event.target.files && event.target.files[0]) {
    const reader = new FileReader();
    reader.onload = (e: any) => this.imgSrc = e.target.result;
    reader.readAsDataURL(event.target.files[0]);
    this.selectedFiles = event.target.files[0];
    this.selectedFiles = event.target.files
  }
  else {
    this.imgSrc = this.imageUrl;
    
  }
}
}
