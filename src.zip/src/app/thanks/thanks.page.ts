import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-thanks',
  templateUrl: './thanks.page.html',
  styleUrls: ['./thanks.page.scss'],
})
export class ThanksPage implements OnInit {

  activeMenu: string;


  constructor(private routes: Router,public menu: MenuController) {
    this.menu1Active();
    screen.orientation.lock('portrait');
  }
  menu1Active() {
    this.activeMenu = 'menu1';
    this.menu.enable(false);
  }
  ngOnInit(){
    setTimeout(() => {
      this.routes.navigateByUrl('login');
          },5000);
        }
}
