
    export interface UserService {
      uid: string;
      Email: string;
      Name: string;
      PhoneNo:number;
      Address: string;
      State:string;
      City:string;
      Pincode: number;
      BDate:string;
      imageUrl:any;
      emailVerified: boolean;
      
   }