import { Injectable, NgZone } from "@angular/core";
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection} from "@angular/fire/firestore";
import * as firebase from 'firebase/app';
import { Router } from "@angular/router";
import { UserService } from "./user.service";
import { AngularFireStorage } from '@angular/fire/storage';
@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {
  userData: firebase.User;
  selectedFile: any;
  itemsRef: AngularFirestoreCollection;
  users: any;
  constructor(
    private afAuth: AngularFireAuth,
    private db: AngularFirestore ,
    private storage: AngularFireStorage,
    public ngZone: NgZone,
    public router: Router   ) {

      
     }
 
     
 

  PasswordRecover(passwordResetEmail) {
    return this.afAuth.sendPasswordResetEmail(passwordResetEmail)
    .then(() => {
      window.alert('Password reset email has been sent, please check your inbox.');
    }).catch((error) => {
      window.alert(error)
    })
  }


  get isEmailVerified(): boolean {
    const user = JSON.parse(localStorage.getItem('user'));
    return (user.emailVerified !== false) ? true : false;
  }
  loginUser(value) {
    return new Promise<any>((resolve, reject) => {
      this.afAuth.signInWithEmailAndPassword(value.email, value.password)
      .then(
          res => {resolve(res)},
          err => reject(err))
    })
  }
  get isLoggedIn(): boolean {
    const user = JSON.parse(localStorage.getItem('user'));
    return (user !== null ) ? true : false;
  }
  logoutUser() {
    return new Promise((resolve, reject) => {
      if (this.afAuth.currentUser) {
        this.afAuth.signOut()
          .then(() => {
            console.log("LOG Out");
            localStorage.removeItem('user');
            resolve();
          }).catch((error) => {
            reject();
          });
      }
    })
  }
 
  userDetails() {
    return this.afAuth.user
  }
}