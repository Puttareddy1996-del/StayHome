import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AngularFirestore,AngularFirestoreCollection } from "@angular/fire/firestore";

import * as firebase from 'firebase/app';
@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart=[];
  
  private cartItemCount=new BehaviorSubject(0);

 
  
  itemsRef: AngularFirestoreCollection;
  fs: any;
  p: any;
  q: any;

  constructor(private db :AngularFirestore,
              ) {
    
   }

  
  getCart(){
    return this.cart;

  }
  

  getCartItemCount(){
    return this.cartItemCount;
  }
  
   addProduct(product){
    let added = false;
    
    
    for(let p of this.cart)
      if(p.id==product.id){
        const NoOfproducts=product.amount+1;
        const TotalCast=product.price*NoOfproducts;
        let currentUser = firebase.auth().currentUser;
      this.db.collection('users').doc(currentUser.uid).collection('orders').doc(product.id).update({amount:NoOfproducts,total:TotalCast});
  
        added =true;
        
      }
    
    if(!added){
      this.cart.push(product);
      
      let record = {};
      record['id'] = product.id;
      record['Name'] =product.Name||product.vegName;
      record['price'] = product.price;
      record['total']=product.price;
      record['imageUrl']=product.imageUrl;
      record['amount']=product.amount;
      record['pDetails']=product.pDetails;
      let currentUser = firebase.auth().currentUser;
     this.db.collection('users').doc(currentUser.uid).collection('orders').doc(product.id).set(record);

      
    }
    this.cartItemCount.next(this.cartItemCount.value+1);
  }

  decreaseProduct(product){
    for(let p of this.cart)
      if(p.id==product.id){
        const NoOfproducts=product.amount -1;
        const TotalCast=product.price*NoOfproducts;
        let currentUser = firebase.auth().currentUser;
      this.db.collection('users').doc(currentUser.uid).collection('orders').doc(product.id).update({amount:NoOfproducts,total:TotalCast});
  
        
      this.cartItemCount.next(this.cartItemCount.value-1);
      
    }
    
    
  }

  removeProduct(product){
    for(let [index,p] of this.cart.entries()){
      if(p.id === product.id){
        this.cartItemCount.next(this.cartItemCount.value-p.amount);
        this.cart.splice(index,1);
        let currentUser = firebase.auth().currentUser;
         this.db.collection('users').doc(currentUser.uid).collection('orders').doc(product.id).delete();
    
      }
      
    }
  }
  
}
