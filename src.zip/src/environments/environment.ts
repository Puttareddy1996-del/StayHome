// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.


export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAqkPW-6G6HLQYJwLzpE1GDQ2rdOGR106U",
    authDomain: "stayhome-6aab6.firebaseapp.com",
    databaseURL: "https://stayhome-6aab6.firebaseio.com",
    projectId: "stayhome-6aab6",
    storageBucket: "stayhome-6aab6.appspot.com",
    messagingSenderId: "916796253734",
    appId: "1:916796253734:web:1488c8251554b8cd2fa8e7",
    measurementId: "G-2M7RWK7P6V"
  }
 };


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
